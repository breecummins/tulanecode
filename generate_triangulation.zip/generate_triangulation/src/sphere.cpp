//
// Author: Ricardo Ortiz <rortizro@caco>, (C) 2009
//
// Copyright: See COPYING file that comes with this distribution
//
// $Id: $

#include <CGAL/Surface_mesh_default_triangulation_3.h>
#include <CGAL/Complex_2_in_triangulation_3.h>
#include <CGAL/make_surface_mesh.h>
#include <CGAL/Implicit_surface_3.h>

#include <vtkXMLUnstructuredGridWriter.h>
#include <vtkUnstructuredGrid.h>
#include <vtkPoints.h>
#include <vtkPointData.h>
#include <vtkCellArray.h>
#include <vtkDoubleArray.h>
#include <vtkType.h>
#include <cmath>

// default triangulation for Surface_mesher
typedef CGAL::Surface_mesh_default_triangulation_3 Tr;

// c2t3
typedef CGAL::Complex_2_in_triangulation_3<Tr> C2t3;

typedef Tr::Geom_traits GT;
typedef GT::Sphere_3 Sphere_3;
typedef GT::Point_3 Point_3;
typedef GT::FT FT;

typedef FT(*Function)(Point_3);

typedef CGAL::Implicit_surface_3<GT, Function> Surface_3;

FT sphere_function(Point_3 p)
{
    const FT x2 = p.x() * p.x(), y2 = p.y() * p.y(), z2 = p.z() * p.z();
    return x2 + y2 + z2 - 1;
}

template <typename C2T3>
void output_to_vtk(const C2T3&, const std::string&);

int main()
{
    Tr tr;            // 3D-Delaunay triangulation
    C2t3 c2t3(tr);    // 2D-complex in 3D-Delaunay triangulation

    // defining the surface
    Surface_3 surface(sphere_function,             // pointer to function
                      Sphere_3(CGAL::ORIGIN, 10.)/*,1e-6*/); // bounding sphere

    // defining meshing criteria
    CGAL::Surface_mesh_default_criteria_3<Tr> criteria(25.,  // angular bound
            0.1,  // radius bound
            0.6); // distance bound
    // meshing surface
    CGAL::make_surface_mesh(c2t3, surface, criteria, CGAL::Non_manifold_tag());

    output_to_vtk(c2t3, "sphere_triangulation.vtu");
    std::cout << "Final number of points: " << tr.number_of_vertices() << "\n";
    std::cout << "Final number of cells: " << tr.number_of_cells() << "\n";
    std::cout << "Final number of edges: " << tr.number_of_edges() << "\n";

}


template <typename C2T3>
void output_to_vtk(const C2T3& c2t3, const std::string &file_name)
{

    typedef typename C2T3::Triangulation Triangulation;
    typedef typename Triangulation::Vertex_handle Vertex_handle;

    const Triangulation& tr = c2t3.triangulation();

    vtkPoints* const vtk_points     = vtkPoints::New();
    vtkCellArray* const vtk_cells   = vtkCellArray::New();
    vtkDoubleArray* velocities      = vtkDoubleArray::New();
    vtkDoubleArray* forces          = vtkDoubleArray::New();
    velocities->SetNumberOfComponents(3);
    velocities->SetName("velocities");
    forces->SetNumberOfComponents(3);
    forces->SetName("forces");

    vtkXMLUnstructuredGridWriter *writer = vtkXMLUnstructuredGridWriter::New();
    vtkUnstructuredGrid *grid = vtkUnstructuredGrid::New();

    vtk_points->Allocate(c2t3.triangulation().number_of_vertices());
    vtk_cells->Allocate(c2t3.number_of_facets());

    std::map<Vertex_handle, vtkIdType> V;
    vtkIdType inum = 0;

    for (typename Triangulation::Finite_vertices_iterator
            vit = tr.finite_vertices_begin(),
            end = tr.finite_vertices_end();
            vit != end;
            ++vit)
    {
        typedef typename Triangulation::Point Point;
        const Point& p = vit->point();
        double pts[3];
        vtk_points->InsertNextPoint(CGAL::to_double(p.x()),
                                    CGAL::to_double(p.y()),
                                    CGAL::to_double(p.z()));
        forces->InsertNextTuple3(0, 0, 0);
        velocities->InsertNextTuple3(0, 0, 0);
        V[vit] = inum++;
    }

    for (typename C2T3::Facet_iterator
            fit = c2t3.facets_begin(),
            end = c2t3.facets_end();
            fit != end; ++fit)
    {
        vtkIdType cell[3];
        int j = 0;

        for (int i = 0; i < 4; ++i)
            if (i != fit->second)
                cell[j++] =  V[(*fit).first->vertex(i)];

        CGAL_assertion(j == 3);

        vtk_cells->InsertNextCell(3, cell);
    }

    grid->SetPoints(vtk_points);

    grid->SetCells(VTK_TRIANGLE, vtk_cells);
    grid->GetPointData()->AddArray(velocities);
    grid->GetPointData()->AddArray(forces);
    vtk_points->Delete();
    vtk_cells->Delete();
    velocities->Delete();
    forces->Delete();

    writer->SetInput(grid);
    grid->Delete();
    writer->SetFileName(file_name.c_str());
    writer->SetDataModeToAscii();
    writer->Write();
    writer->Delete();


}
// kate: indent-mode cstyle; space-indent on; indent-width 4; 
